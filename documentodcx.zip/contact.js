

ScrollReveal({
    reset: false,  
    distance: "80px",
    duration: 2000,
    delay: 200,
  });
 ScrollReveal().reveal(".home-content, .heading , ", { origin: "top" });
ScrollReveal().reveal(".home-img, ", { origin: "bottom" });
ScrollReveal().reveal(".education-content , .dev-icons ,  .contact p , .son-animation .box ", { origin: "right" }); 
ScrollReveal().reveal(".git , .about-lenguaje , .lenguajes", { origin: "right" }); 
ScrollReveal().reveal(".fack , .about-img  , .about-content h1 ,  .contact .heading", { origin: "left" }); 
ScrollReveal().reveal(".about-lenguaje p ,  .contact .in , .contact .btn", { origin: "bottom" });
